import requests

def lambda_handler(event, context):
    # print("hello world")
    data = [
    ('payload', '{"channel": "#general", "text": "This is posted to #general and comes from a bot named webhookbot. test"}'),
    ]

    response = requests.post('https://hooks.slack.com/services/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', data=data, verify=False)

    return response.status_code

if __name__ == '__main__':
    lambda_handler("","")